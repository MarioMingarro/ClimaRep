#' @keywords internal
#' @aliases ClimaRep
"_PACKAGE"

#' @title ClimaRep: Estimating Climate Representativeness
#' @description
#' ## Overview
#' The primary goal of `ClimaRep` is to quantify how well the climate within specific polygons (`sf`) represents the broader climate space defined by climate variables (`SpatRaster`) within a study area (`sf`).
#' It also provides functions to evaluate how this representativeness changes under projected future climate conditions.
#'
#' ## Key Features
#' The package includes functions for:
#' * Filtering raster climate variables to reduce multicollinearity (\link{ClimaRep::vif_filter}).
#' * Estimating current climate representativeness (\link{ClimaRep::mh_rep}).
#' * Estimating changes in climate representativeness under future climate projections (\link{ClimaRep::mh_rep_ch}).
#' * Estimating climate representativeness overlay (\link{ClimaRep::rep_overlay}).
#'
#' ## More Details
#' https://github.com/MarioMingarro/ClimaRep
#' @name ClimaRep-package
NULL
